import Alpine from "alpinejs";
import "phoenix_html"
import {Socket} from "phoenix"
import topbar from "topbar"
import {LiveSocket} from "phoenix_live_view"
import Clipboard from "@ryangjchandler/alpine-clipboard";
import Swiper from 'swiper';
import {EffectCards} from "swiper/modules"
import {startBasicCall, cleanup} from "./agora.js"

Alpine.plugin(Clipboard)

let hooks = {
  VoiceCall : {
    mounted() {
      const view = this.el.dataset.view;
      console.log(`VoiceCall mounted for ${view}`);
      startBasicCall(view);
    },
    destroyed() {
      cleanup();
    }
  },
  Swiper: {
    mounted() {
      console.log("Swiper mounted")
      this.initializeSwiper();
    },
    updated() {
      // Reinitialize or update Swiper when LiveView updates the DOM
      // this.swiperThumbnail.destroy(true, true); // Destroy the current instance
      this.swiper.destroy(true, true); // Destroy the current instance
      this.initializeSwiper(); // Reinitialize
    },
    destroyed() {
      if (this.swiper) {
        this.swiper.destroy(true, true);
      }
    },
    initializeSwiper() {
       this.swiper = new Swiper('.deck', {
        modules: [EffectCards],
         effect: 'cards',
         cardsEffect: {
           perSlideOffset: 8,
           perSlideRotate: 2
         },
        slidesPerView: 1,
        centeredSlides: true,
        loop: false,
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        },
      })
    }
  }
}

let csrfToken = document.querySelector("meta[name='csrf-token']").getAttribute("content")
let liveSocket = new LiveSocket("/live", Socket, {
  params: {_csrf_token: csrfToken}, dom: {
    onBeforeElUpdated(from, to) {
      if (from._x_dataStack) {
        window.Alpine.clone(from, to);
      }
    }
  },
  hooks: hooks
})



window.Alpine = Alpine;
Alpine.start();

// Show progress bar on live navigation and form submits
topbar.config({barColors: {0: "#29d"}, shadowColor: "rgba(0, 0, 0, .3)"})
window.addEventListener("phx:page-loading-start", info => topbar.show())
window.addEventListener("phx:page-loading-stop", info => topbar.hide())

// connect if there are any LiveViews on the page
liveSocket.connect()

// expose liveSocket on window for web console debug logs and latency simulation:
// >> liveSocket.enableDebug()
// >> liveSocket.enableLatencySim(1000)  // enabled for duration of browser session
// >> liveSocket.disableLatencySim()
window.liveSocket = liveSocket

