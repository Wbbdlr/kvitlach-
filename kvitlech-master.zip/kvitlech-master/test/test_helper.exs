ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Kurten.Repo, :manual)
