defmodule KurtenWeb.Layouts do
  use KurtenWeb, :html

  embed_templates "layouts/*"
end
